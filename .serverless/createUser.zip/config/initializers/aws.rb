Aws.config.update({
                    region: 'us-west-2',
                    credentials: Aws::Credentials.new('AKIA4WEH4RYR7RSG76XI',
                                                      '5/h6KGRHC3dci9QY/+9yIVwi14iwZtJvBhgPXeM0')
                  })
